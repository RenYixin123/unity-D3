using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TransScene: MonoBehaviour
{
    // Start is called before the first frame update
   //void Start()
  //  {
       // this.GetComponent<Button>().TS.AddListener(TS);
  //  }

  public void TS()
    {
       SceneManager.LoadScene("Game2");

  }

    // Update is called once per frame
    //void Update()
    //{

    //}

}
