using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class DuiHua : MonoBehaviour
{
    public string m_DuiHuaStr;

    public TMP_Text m_Str;

    private int m_Index;

    private float m_CurTime;

    public float m_JianGeTime;

    private bool m_IsStart = true;

    
    void Update()
    {
        if(m_IsStart)
        {
            m_CurTime += Time.deltaTime;

            if (m_CurTime >= m_JianGeTime)
            {
                m_Index++;

                if (m_Index >= m_DuiHuaStr.Length)
                {
                    m_IsStart = false;
                    m_Index = 0;
                }
                    
                m_CurTime = 0;

                if (m_Str != null)
                {
                    char tmpstr = m_DuiHuaStr[m_Index];
                    m_Str.text += tmpstr;
                }
            } 
        } 
    }
}
