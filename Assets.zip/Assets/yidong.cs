using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class yidong : MonoBehaviour
{
    public float Speed;//���������ƶ��ٶ�
    public Transform Me;//���ƶ�������
    private void Update()
    {
        if (Input.GetKey(KeyCode.A))
        {
            Me.position += Vector3.left * Time.deltaTime * Speed;
        }
        if (Input.GetKey(KeyCode.D))
        {
            Me.position += Vector3.right * Time.deltaTime * Speed;
        }
    }

}
